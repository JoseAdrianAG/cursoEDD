package inici;

import altres.Equip;
import personatges.Alien;
import personatges.Guerrer;
import personatges.Huma;
import personatges.Jugador;
import Teclat.*;

public class JocDeRol {

    static void provaFase1() {
        System.out.println("Vaig a crear un Huma");
        //Huma h1=new Huma();
        System.out.println("Vaig a crear un Guerrer");
        //Guerrer g1=new Guerrer();
        System.out.println("Vaig a crear un Alien");
        //Alien a1=new Alien();

    }

    static void provaFase2() {
        Jugador h2 = new Huma("Adrian", 13, 8, 39);
        Jugador g2 = new Guerrer("Paco", 27, 2, 32);

        h2.toString();
    }

    static void provaFase3() {
        Jugador h2 = new Huma("Adrian", 5, 8, 120);
        Jugador g2 = new Guerrer("Paco", 35, 2, 21);
        Jugador a2 = new Alien("E.T", 22, 10, 22);
        h2.toString();
        g2.toString();
        a2.toString();

        h2.ataca(g2);
        g2.ataca(a2);
    }

    static void provaFase4() {
        Jugador h3 = new Huma("David", 15, 7, 40);
        Jugador h4 = new Huma("Pep", 15, 7, 40);

        Jugador g3 = new Guerrer("Pablo", 27, 5, 50);
        Jugador g4 = new Guerrer("Pedro", 27, 5, 50);

        Equip e1 = new Equip("Humanos");
        Equip e2 = new Equip("Guerreros");

        e1.posa(h3);
        e1.posa(h4);
        e1.toString();

        e2.posa(g3);
        e2.posa(g4);

        h3.toString();//NO FUNCIONA
        e2.toString();//NO FUNCIONA

        e1.lleva(h3);
        e2.lleva(g3);

    }

    static void menuConfiguracio() {
        int menu = Teclat.lligOpcio("CONFIGURACIÓ", "Jugadors", "Equips", "Poders");

        switch (menu) {
            case 1:
                Jugadors.menu();
                break;

            case 2:
                Equips.menu();
                break;

            case 3:
                Poders.menu();
                break;

            case 0:
                menu();
                break;

        }
    }

    static void jugar() {

        boolean repetir = true;

        while (repetir == true) {

            for (Jugador jugador : Jugadors.llista) {

                System.out.println(Jugadors.llista);
                System.out.println("Turno de atacar: " + jugador.getNom());
                String elegJugAtacar = Teclat.lligString("Dime a que jugador de la lista quieres atacar");
                Jugador j = new Jugador(elegJugAtacar, 0, 0, 0);
                if(j.equals(jugador)) {
                    System.out.println("No puedes atacar al mismo jugador");
                    elegJugAtacar = Teclat.lligString("Dime a que jugador de la lista quieres atacar");
                } else {

                    if (Jugadors.llista.contains(j)) {
                        int posJugAtacar = Jugadors.llista.indexOf(j);
                        jugador.ataca(Jugadors.llista.get(posJugAtacar));
                    } else {
                        System.out.println("No existe ese jugador");
                        elegJugAtacar = Teclat.lligString("Dime a que jugador de la lista quieres atacar");
                    }
                }

                if(jugador.getVides()==0){
                    System.out.println(jugador.getNom()+" es eliminado");
                    Jugadors.llista.remove(jugador);
                }
                if (Jugadors.llista.size() == 1) {
                    repetir = false;
                    System.out.println(Jugadors.llista);
                    System.out.println("El ganador es: "+Jugadors.llista);
                }

            }
        }

    }

    static void menu() {
        int menu = Teclat.lligOpcio("JOC DE ROL", "Configuració", "Jugar");

        boolean repetir = true;
        while (repetir == true) {

            switch (menu) {
                case 1:
                    menuConfiguracio();
                    break;

                case 2:
                    jugar();
                    break;

                case 0:
                    repetir = false;
                    break;
            }
        }
    }

    public static void main(String[] args) {

        //provaFase1();
        //Guerrer g2=new Guerrer("Adrian",10,10,5);
        //provaFase2();
        //provaFase3();
        //provaFase4();
        menu();
    }

}
