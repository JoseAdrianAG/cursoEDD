package inici;

import Teclat.Teclat;
import java.util.ArrayList;
import altres.Poder;

public class Poders {

    static ArrayList<Poder> llista = new ArrayList();

    static void menu() {
        int menuPoders = Teclat.lligOpcio("PODERS", "Crear", "Consultar", "Eliminar");

        switch (menuPoders) {
            case 1:
                crear();
                break;

            case 2:
                consultar();
                break;

            case 3:
                eliminar();
                break;

        }

    }

    static void crear() {
        String nomPoder = Teclat.lligString("Dime el nombre para el poder");
        int bonusAtac = Teclat.lligInt("Dime cuantos puntos de ataque quieres");
        int bonusDefensa = Teclat.lligInt("Dime cuantos puntos de defensa quieres");
        Poder p = new Poder(nomPoder, bonusAtac, bonusDefensa);
        if (!llista.contains(p)) {
            llista.add(p);
        }
    }

    static void consultar() {
        for (Poder poder : llista) {
            System.out.println(poder);
        }
    }

    static void eliminar() {
        String eliminarPoder = Teclat.lligString("Dime el nombre del poder que quieres eliminar");
        Poder poderAEliminar=new Poder(eliminarPoder,0,0);
        llista.remove(llista.indexOf(poderAEliminar));
        System.out.println("Poder eliminado correctamente");
    }

}
