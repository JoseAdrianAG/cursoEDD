package inici;

import java.util.ArrayList;
import personatges.Jugador;
import Teclat.*;
import altres.Equip;
import altres.Poder;
import personatges.Alien;
import personatges.Guerrer;
import personatges.Huma;

public class Jugadors {

    static ArrayList<Jugador> llista = new ArrayList();

    static void menu() {
        int menuJugadors = Teclat.lligOpcio("JUGADORS", "Crear", "Consultar", "Eliminar", "Assignar a equip", "Llevar d'equip", "Assignar poder");

        switch (menuJugadors) {
            case 1:
                crear();
                break;

            case 2:
                consultar();
                break;

            case 3:
                eliminar();
                break;

            case 4:
                assignarEquip();
                break;

            case 5:
                llevarEquip();
                break;

            case 6:
                assignarPoder();
                break;

        }

    }

    static void crear() {
        char tipusJugador = Teclat.lligChar("Dime el tipo de jugador que quieres crear", "HGA");

        String nomJugador = Teclat.lligString("Dime el nombre para el jugador");

        int pAtac = Teclat.lligInt("Dime los puntos de ataque",50,100);

        int pDefensa = 0;

        int pTotals = pAtac + pDefensa;
        if (pTotals != 100) {
            pDefensa = 100 - pAtac;
        }

        int vides = 0;

        switch (tipusJugador) {
            case 'H':
                Huma h = new Huma(nomJugador, pAtac, pDefensa, vides);
                if (!llista.contains(h)) {
                    llista.add(h);
                    System.out.println("Jugador creado correctamente");
                } else {
                    System.out.println("Ya hay un jugador con ese nombre");
                }
                break;

            case 'G':
                Guerrer g = new Guerrer(nomJugador, pAtac, pDefensa, vides);
                if (!llista.contains(g)) {
                    llista.add(g);
                    System.out.println("Jugador creado correctamente");
                } else {
                    System.out.println("Ya hay un jugador con ese nombre");
                }
                break;

            case 'A':
                Alien a = new Alien(nomJugador, pAtac, pDefensa, vides);
                if (!llista.contains(a)) {
                    llista.add(a);
                    System.out.println("Jugador creado correctamente");
                } else {
                    System.out.println("Ya hay un jugador con ese nombre");
                }
                break;
        }
    }

    static void consultar() {
        for (Jugador jugador : llista) {
            System.out.println(jugador);

        }
    }

    static void eliminar() {
        String eliminarjugador = Teclat.lligString("Dime el nombre del jugador que quieres borrar");
        Jugador jugadorAEliminar = new Jugador(eliminarjugador, 0, 0, 0);
        llista.remove(llista.indexOf(jugadorAEliminar));
        System.out.println("Eliminado correctamente");
    }

    

    static void llevarEquip() {
        String nomjugador = Teclat.lligString("Dime el nombre del jugador");
        String nomequip = Teclat.lligString("Dime el nombre del equipo");

        Jugador jugadorAEliminar = new Jugador(nomjugador, 0, 0, 0);
        Equip equipAEliminar = new Equip(nomequip);
        if (llista.contains(jugadorAEliminar)) {
            int posNomJugador = llista.indexOf(jugadorAEliminar);
            Jugador jugador = llista.get(posNomJugador);
            if (Equips.llista.contains(equipAEliminar)) {
                int posNomEquip = Equips.llista.indexOf(equipAEliminar);
                Equip equipo = Equips.llista.get(posNomEquip);
                equipo.lleva(jugador);
                System.out.println("Jugador eliminado correctamente del equipo");
            } else {
                System.out.println("No existe este equipo");
            }
        } else {
            System.out.println("No existe este jugador");
        }

    }
    static void assignarEquip() {
        String nomjugador = Teclat.lligString("Dime el nombre del jugador");
        String nomequip = Teclat.lligString("Dime el nombre del equipo");

        Jugador jugadorABuscar = new Jugador(nomjugador, 0, 0, 0);
        Equip equipABuscar = new Equip(nomequip);
        if (llista.contains(jugadorABuscar)) {
            int posNomJugador = llista.indexOf(jugadorABuscar);
            Jugador jugador = llista.get(posNomJugador);
            if (Equips.llista.contains(equipABuscar)) {
                int posNomEquip = Equips.llista.indexOf(equipABuscar);
                Equip equipo = Equips.llista.get(posNomEquip);
                equipo.posa(jugador);
                System.out.println("Jugador añadido correctamente al equipo");
            } else {
                System.out.println("No existe este equipo");
            }
        } else {
            System.out.println("No existe este jugador");
        }

    }

    static void assignarPoder() {
        String nomjugador = Teclat.lligString("Dime el nombre del jugador");
        String nompoder = Teclat.lligString("Dime el nombre del poder");

        Jugador jugadorAAssignar = new Jugador(nomjugador, 0, 0, 0);
        Poder poderAAssignar = new Poder(nompoder, 0, 0);
        if (llista.contains(jugadorAAssignar)) {
            int posNomJugador = llista.indexOf(jugadorAAssignar);
            Jugador jugador = llista.get(posNomJugador);
            if (Poders.llista.contains(poderAAssignar)) {
                int posNomPoder = Poders.llista.indexOf(poderAAssignar);
                Poder poder = Poders.llista.get(posNomPoder);
                jugador.posa(poder);
                System.out.println("Poder asignado correctamente");
            }
            else{
                System.out.println("No existe este poder");
            }
        }
        else{
            System.out.println("No existe este jugador");
        }

    }

}
