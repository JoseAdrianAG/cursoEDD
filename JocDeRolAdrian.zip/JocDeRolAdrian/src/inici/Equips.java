package inici;

import altres.Equip;
import java.util.ArrayList;
import Teclat.*;

public class Equips {

    static ArrayList<Equip> llista = new ArrayList();

    static void menu() {
        int menuEquips = Teclat.lligOpcio("EQUIPS", "Crear", "Consultar", "Eliminar");

        switch (menuEquips) {
            case 1:
                crear();
                break;

            case 2:
                consultar();
                break;

            case 3:
                eliminar();
                break;

            case 0:
                JocDeRol.menu();
                break;

        }

    }

    static void crear() {
        String nomEquip = Teclat.lligString("Dime el nombre para el equipo");
        Equip e = new Equip(nomEquip);
        if (!llista.contains(e)) {
            llista.add(e);
            System.out.println("Equipo creado correctamente");
        } else {
            System.out.println("Ya hay un equipo con ese nombre");
        }
    }

    static void consultar() {
        for (Equip equip : llista) {
            System.out.println(equip);
        }
    }

    static void eliminar() {
        String eliminarEquip = Teclat.lligString("Dime el nombre del equipo que quieres borrar");
        Equip equipAEliminar = new Equip(eliminarEquip);
        llista.remove(llista.indexOf(equipAEliminar));
        System.out.println("Equipo eliminado correctamente");
    }

}
