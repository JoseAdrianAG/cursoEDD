package personatges;

import altres.Equip;
import altres.Poder;
import java.util.ArrayList;
import java.util.Objects;

public class Jugador {

    private String nom;
    private int puntsAtac;
    private int puntsDefensa;
    private int vides;
    private Equip equip;
    private ArrayList<Poder> poders = new ArrayList();
    static int videsInicials = 200;

    public Equip getEquip() {
        return equip;
    }

    public void setEquip(Equip equip) {
        if (this.equip == equip) {
            return;
        }

        Equip oldEquip = this.equip;
        this.equip = equip;

        if (oldEquip != null) {
            oldEquip.lleva(this);
        }

        if (equip != null) {
            equip.posa(this);
        }

    }

    public Jugador(String nom, int puntsAtac, int puntsDefensa, int vides) {
        System.out.println("Soc el constructor de Jugador, pero estic creant un " + this.getClass().getSimpleName());
        this.nom = nom;
        this.puntsAtac = puntsAtac;
        this.puntsDefensa = puntsDefensa;
        this.vides = videsInicials;
    }

    public String getNom() {
        return nom;
    }

    public int getPuntsAtac() {
        return puntsAtac;
    }

    public int getPuntsDefensa() {
        return puntsDefensa;
    }

    public int getVides() {
        return vides;
    }

    protected void setNom(String nom) {
        this.nom = nom;
    }

    protected void setPuntsAtac(int puntsAtac) {
        this.puntsAtac = puntsAtac;
    }

    protected void setPuntsDefensa(int puntsDefensa) {
        this.puntsDefensa = puntsDefensa;
    }

    protected void setVides(int vides) {
        this.vides = vides;
    }

    @Override
    public String toString() {
        if (equip == null) {
            return nom + "[" + null + "]" + "( " + this.getClass().getSimpleName() + ", PA:" + puntsAtac + ", PD:" + puntsDefensa + ", PV:" + vides + " )";

        }
        return nom + "[" + getEquip().getNom() + "]" + "( " + this.getClass().getSimpleName() + ", PA:" + puntsAtac + ", PD:" + puntsDefensa + ", PV:" + vides + " )";
    }

    protected void esColpejatAmb(int puntsAtac) {
        for (Poder poder : poders) {
            this.puntsDefensa += poder.getBonusDefensa();
        }

        int videsLlevar = puntsAtac - this.puntsDefensa;
        if (videsLlevar < 0) {
            videsLlevar = 0;
        }

        int videsRestants = vides - videsLlevar;

        if (videsRestants < 0) {
            videsRestants = 0;
        }
        

        System.out.println(nom + " es colpejat amb " + puntsAtac + " punts i es defen amb " + puntsDefensa + ". Vides: " + vides + " - " + videsLlevar + " = " + videsRestants);
        vides = videsRestants;
    }

    public void ataca(Jugador obj) {
        System.out.println("ABANS DE L'ATAC:");
        System.out.println("\tAtacant: " + this.toString());
        System.out.println("\tAtacat: " + obj.toString());

        for (Poder poder : poders) {
            this.puntsAtac += poder.getBonusAtac();
        }
        obj.esColpejatAmb(puntsAtac);
        this.esColpejatAmb(obj.puntsAtac);

        System.out.println("DESPRES DE L'ATAC:");
        System.out.println("\tAtacant: " + this.toString());
        System.out.println("\tAtacat: " + obj.toString());

    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }

        final Jugador other = (Jugador) obj;

        return Objects.equals(this.nom, other.nom);
    }

    public void posa(Poder poder) {
        if (!poders.contains(poder)) {
            poders.add(poder);
        }

    }

    public void lleva(Poder poder) {
        if (poders.contains(poder)) {
            poders.remove(poder);
        }

    }

}
