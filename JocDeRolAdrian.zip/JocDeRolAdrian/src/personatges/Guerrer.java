package personatges;
import personatges.Jugador;
public class Guerrer extends Huma{

    public Guerrer(String nom, int puntsAtac, int puntsDefensa, int vides) {
        super(nom,
        puntsAtac,
        puntsDefensa,
        vides);
        
        
        
        
        System.out.println("Soc el constructor de Guerrer, pero estic creant un "+this.getClass().getSimpleName());
        
    }
    @Override
    protected void esColpejatAmb(int puntsAtac) {
        int videsLlevar = puntsAtac - this.getPuntsDefensa();
        
        int videsRestants=this.getVides()-videsLlevar;
        
        if (videsRestants < 0) {
            videsRestants = 0;
        }
        if(videsLlevar<5){
            videsRestants=this.getVides();
        }
        
        System.out.println(this.getNom()+" es colpejat amb "+puntsAtac+" punts i es defen amb "+this.getPuntsDefensa()+". Vides: "+this.getVides()+" - "+videsLlevar+" = "+videsRestants);
        this.setVides(videsRestants);
    }
    
    
}