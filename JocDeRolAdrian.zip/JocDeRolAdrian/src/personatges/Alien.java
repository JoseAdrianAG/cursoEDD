package personatges;

public class Alien extends Jugador{

    public Alien(String nom, int puntsAtac, int puntsDefensa, int vides) {
        super(nom,
        puntsAtac,
        puntsDefensa,
        vides);
        
        if(vides>20){
            setPuntsAtac(puntsAtac+3);
            setPuntsDefensa(puntsDefensa-3);
        }
        if(vides<=20){
            setPuntsAtac(puntsAtac);
            setPuntsDefensa(puntsDefensa);
        }
        

        System.out.println("Soc el constructor de Alien, pero estic creat un "+this.getClass().getSimpleName());
            }
    
    @Override
    protected void esColpejatAmb(int puntsAtac) {
        int videsLlevar = puntsAtac - this.getPuntsDefensa();
        
        int videsRestants=this.getVides()-videsLlevar;
        
        if (videsRestants < 0) {
            videsRestants = 0;
        }
        
        
        System.out.println(this.getNom()+" es colpejat amb "+puntsAtac+" punts i es defen amb "+this.getPuntsDefensa()+". Vides: "+this.getVides()+" - "+videsLlevar+" = "+videsRestants);
        this.setVides(videsRestants);
    }
    
    
}
