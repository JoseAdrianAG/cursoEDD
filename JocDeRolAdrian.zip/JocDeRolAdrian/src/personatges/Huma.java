package personatges;

public class Huma extends Jugador {

    public Huma(String nom, int puntsAtac, int puntsDefensa, int vides) {
        super(nom,
                puntsAtac,
                puntsDefensa,
                vides);

        if (this.getVides() > 100) {
            this.setVides(100);
        }

        System.out.println("Soc el constructor de Huma pero estic creant un " + this.getClass().getSimpleName());

    }

    @Override
    protected void esColpejatAmb(int puntsAtac) {
        int videsLlevar = puntsAtac - this.getPuntsDefensa();

        int videsRestants = this.getVides() - videsLlevar;

        if (videsRestants < 0) {
            videsRestants = 0;
        }

        System.out.println(this.getNom() + " es colpejat amb " + puntsAtac + " punts i es defen amb " + this.getPuntsDefensa() + ". Vides: " + this.getVides() + " - " + videsLlevar + " = " + videsRestants);
        this.setVides(videsRestants);
    }

}
