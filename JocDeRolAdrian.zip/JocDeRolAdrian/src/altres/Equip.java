package altres;

import java.util.ArrayList;
import java.util.Objects;
import personatges.Jugador;

public class Equip {

    private String nom;
    ArrayList<Jugador> jugadors = new ArrayList();

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Equip(String nom) {
        this.nom = nom;
    }

    public void posa(Jugador j) {

        if (!jugadors.contains(j)) {
            jugadors.add(j);
            j.setEquip(this); 
        }
        
    }

    public void lleva(Jugador nomJugador) {
        if (jugadors.contains(nomJugador)) {
            jugadors.remove(nomJugador);
            nomJugador.setEquip(null);
        }

    }
    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        
        final Equip other = (Equip) obj;

        return Objects.equals(this.nom, other.nom);
    }

    @Override
    public String toString() {
        return "Equip " + nom + ":\n"
                + jugadors;
    }

}
