

import Teclat.*;

public class escacsAglioAdrian {

    //Funcion para convertir las letras de las columnas a numeros
    public static int letrascolumna(char coleleg) {
        int colelegnum = 0;
        switch (coleleg) {
            case 'a':
            case 'A':
                colelegnum = 1;
                break;
            case 'b':
            case 'B':
                colelegnum = 2;
                break;
            case 'c':
            case 'C':
                colelegnum = 3;
                break;
            case 'd':
            case 'D':
                colelegnum = 4;
                break;
            case 'e':
            case 'E':
                colelegnum = 5;
                break;
            case 'f':
            case 'F':
                colelegnum = 6;
                break;
            case 'g':
            case 'G':
                colelegnum = 7;
                break;
            case 'h':
            case 'H':
                colelegnum = 8;
                break;
            case 'i':
            case 'I':
                colelegnum = 9;
                break;
        }
        return colelegnum;
    }

    //Funcion para convertir los numeros de las columnas a letras
    public static char numcolumnas(int columna) {
        char coleleg = ' ';
        switch (columna) {
            case 1:
                coleleg = 'a';
                break;
            case 2:
                coleleg = 'b';
                break;
            case 3:
                coleleg = 'c';
                break;
            case 4:
                coleleg = 'd';
                break;
            case 5:
                coleleg = 'e';
                break;
            case 6:
                coleleg = 'f';
                break;
            case 7:
                coleleg = 'g';
                break;
            case 8:
                coleleg = 'h';
                break;
            case 9:
                coleleg = 'i';
                break;
        }
        return coleleg;

    }

    public static void main(String[] args) {

        int FILA = Teclat.lligInt("Dime cuantas filas tiene el tablero", 5, 9);
        int COL = Teclat.lligInt("Dime cuantas columnas tiene el tablero", 5, 9);

        //Espacio en blanco
        char tablero[][] = new char[FILA + 2][COL + 2];
        final char Blanco = '_';

        //Tablero
        int filas = 0;
        int columnas = 0;
        for (filas = 0; filas < tablero.length; filas++) {
            for (columnas = 0; columnas < tablero.length; columnas++) {
                tablero[filas][columnas] = Blanco;

            }

        }
        char[] letrasCol = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
        char marcamov = '*';
        boolean repetir = true;
        while (repetir == true) {

            System.out.print("  ");
            for (int i = 0; i < COL; i++) {
                System.out.print(letrasCol[i] + " ");
            }
            System.out.println();

            for (filas = 1; filas <= FILA; filas++) {
                System.out.print(filas + "|");
                for (columnas = 1; columnas <= COL; columnas++) {
                    System.out.print(tablero[filas][columnas] + "|");
                }
                System.out.println(" " + filas);
            }

            System.out.print("  ");
            for (int i = 0; i < COL; i++) {
                System.out.print(letrasCol[i] + " ");
            }
            System.out.println();

            //Menu
            System.out.println("1-Posar una peça");
            System.out.println("2-Mostrar els moviments de una peça");
            System.out.println("3-Esborrar moviments");
            System.out.println("4-Esborrar tauler");
            System.out.println("5-Eixir");

            int opcion = Teclat.lligInt("¿Que opcion quieres?");
            switch (opcion) {
                //Elegir que pieza poner en el tablero
                case 1:
                    char pieza = Teclat.lligChar("¿Que pieza quieres(T, A, D, R o C)?");
                    if (pieza == 't' || pieza == 'T' || pieza == 'a' || pieza == 'A' || pieza == 'd' || pieza == 'D' || pieza == 'r' || pieza == 'R' || pieza == 'c' || pieza == 'C') {

                        int filaeleg = Teclat.lligInt("Dime en que fila quieres colocar la pieza", 1, FILA);
                        char coleleg = Teclat.lligChar("Dime en que columna quieres colocar la pieza(a-" + numcolumnas(COL) + ")");
                        int colelegnum = letrascolumna(coleleg);

                        tablero[filaeleg][colelegnum] = pieza;
                    }
                    break;
                //Poner marcas de movimiento
                case 2:
                    int pedirfila = Teclat.lligInt("Dime la fila de la pieza que quieras mover", 1, FILA);
                    char pedircol = Teclat.lligChar("Dime en que columna quieres colocar la pieza(a, b, c, d, e, f, g, h, i)");
                    int pedircolnum = letrascolumna(pedircol);

                    switch (tablero[pedirfila][pedircolnum]) {
                        //Movimientos torre
                        case 't':
                        case 'T':
                            //Marcas hacia arriba
                            for (int i = pedirfila - 1; i >= 1; i--) {
                                if (tablero[i][pedircolnum] == Blanco) {
                                    tablero[i][pedircolnum] = marcamov;
                                } else if (tablero[i][pedircolnum] != marcamov) {
                                    break;
                                }
                            }
                            //Marcas hacia la izquierda
                            for (int i = pedircolnum - 1; i >= 1; i--) {
                                if (tablero[pedirfila][i] == Blanco) {
                                    tablero[pedirfila][i] = marcamov;
                                } else if (tablero[pedirfila][i] != marcamov) {

                                    break;
                                }
                            }
                            //Marcas hacia abajo
                            for (int i = pedirfila + 1; i <= FILA; i++) {
                                if (tablero[i][pedircolnum] == Blanco) {
                                    tablero[i][pedircolnum] = marcamov;
                                } else if (tablero[i][pedircolnum] != marcamov) {
                                    break;
                                }
                            }
                            //Marcas hacia la derecha
                            for (int i = pedircolnum + 1; i <= COL; i++) {
                                if (tablero[pedirfila][i] == Blanco) {
                                    tablero[pedirfila][i] = marcamov;
                                } else if (tablero[pedirfila][i] != marcamov) {
                                    break;
                                }
                            }
                            break;
                        //Movimientos alfil
                        case 'a':
                        case 'A':
                            //Marcas en diagonal de arriba izquierda
                            for (int i = pedirfila - 1, j = pedircolnum - 1; i >= 1 && j >= 1; i--, j--) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }

                            //Marcas en diagonal de arriba derecha
                            for (int i = pedirfila - 1, j = pedircolnum + 1; i >= 1 && j <= COL; i--, j++) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }

                            //Marcas en diagonal de abajo izquierda
                            for (int i = pedirfila + 1, j = pedircolnum - 1; i <= FILA && j >= 1; i++, j--) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }

                            //Marcas en diagonal de abajo derecha
                            for (int i = pedirfila + 1, j = pedircolnum + 1; i <= FILA && j <= COL; i++, j++) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }
                            break;
                        //Movimientos dama
                        case 'd':
                        case 'D':
                            //Marcas hacia arriba
                            for (int i = pedirfila - 1; i >= 1; i--) {
                                if (tablero[i][pedircolnum] == Blanco) {
                                    tablero[i][pedircolnum] = marcamov;
                                } else if (tablero[i][pedircolnum] != marcamov) {
                                    break;
                                }
                            }
                            //Marcas hacia la izquierda
                            for (int i = pedircolnum - 1; i >= 1; i--) {
                                if (tablero[pedirfila][i] == Blanco) {
                                    tablero[pedirfila][i] = marcamov;
                                } else if (tablero[pedirfila][i] != marcamov) {

                                    break;
                                }
                            }
                            //Marcas hacia abajo
                            for (int i = pedirfila + 1; i <= FILA; i++) {
                                if (tablero[i][pedircolnum] == Blanco) {
                                    tablero[i][pedircolnum] = marcamov;
                                } else if (tablero[i][pedircolnum] != marcamov) {
                                    break;
                                }
                            }
                            //Marcas hacia la derecha
                            for (int i = pedircolnum + 1; i <= COL; i++) {
                                if (tablero[pedirfila][i] == Blanco) {
                                    tablero[pedirfila][i] = marcamov;
                                } else if (tablero[pedirfila][i] != marcamov) {
                                    break;
                                }
                            }
                            //Marcas en diagonal de arriba izquierda
                            for (int i = pedirfila - 1, j = pedircolnum - 1; i >= 1 && j >= 1; i--, j--) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }

                            //Marcas en diagonal de arriba derecha
                            for (int i = pedirfila - 1, j = pedircolnum + 1; i >= 1 && j <= COL; i--, j++) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }

                            //Marcas en diagonal de abajo izquierda
                            for (int i = pedirfila + 1, j = pedircolnum - 1; i <= FILA && j >= 1; i++, j--) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }

                            //Marcas en diagonal de abajo derecha
                            for (int i = pedirfila + 1, j = pedircolnum + 1; i <= FILA && j <= COL; i++, j++) {
                                if (tablero[i][j] == Blanco) {
                                    tablero[i][j] = marcamov;
                                } else if (tablero[i][j] != marcamov) {
                                    break;
                                }
                            }
                            break;
                        //Movimientos rey
                        case 'r':
                        case 'R':
                            for (int i = -1; i <= 1; i++) {
                                for (int j = -1; j <= 1; j++) {
                                    int filarey = pedirfila + i;
                                    int colrey = pedircolnum + j;

                                    if (filarey >= 1 && filarey <= FILA && colrey >= 1 && colrey <= COL) {
                                        if (tablero[filarey][colrey] == Blanco && (i != 0 || j != 0)) {
                                            tablero[filarey][colrey] = marcamov;
                                        }
                                    }
                                }
                            }
                            break;
                        //Movimientos caballo
                        case 'c':
                        case 'C':
                            int[] movFila = {-2, -1, 1, 2, 2, 1, -1, -2};
                            int[] movCol = {1, 2, 2, 1, -1, -2, -2, -1};

                            for (int i = 0; i < 8; i++) {
                                int nuevaFila = pedirfila + movFila[i];
                                int nuevaCol = pedircolnum + movCol[i];

                                if (nuevaFila >= 1 && nuevaFila <= FILA && nuevaCol >= 1 && nuevaCol <= COL && tablero[nuevaFila][nuevaCol] == Blanco) {
                                    tablero[nuevaFila][nuevaCol] = marcamov;
                                }
                            }
                            break;
                    }
                    break;
                //Borrar las marcas con contador
                case 3:
                    int contmb = 0;
                    for (int i = 1; i <= FILA; i++) {
                        for (int j = 1; j <= COL; j++) {
                            if (tablero[i][j] == marcamov) {
                                tablero[i][j] = Blanco;
                                contmb++;

                            }

                        }

                    }
                    System.out.println("Marcas borradas: " + contmb);

                    break;
                //Borrar las piezas y marcas del tablero
                case 4:
                    for (int i = 1; i <= FILA; i++) {
                        for (int j = 1; j <= COL; j++) {
                            tablero[i][j] = Blanco;
                        }
                    }
                    break;
                //Salir
                case 5:
                    char salir = Teclat.lligChar("Quieres salir(s/n)");
                    if (salir == 's' || salir == 'S') {
                        repetir = false;
                    }
            }

        }

    }

}
